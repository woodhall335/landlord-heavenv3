export { metadata } from '../money-claim/page';
export { default } from '../money-claim/page';
