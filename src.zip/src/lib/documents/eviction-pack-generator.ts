/**
 * Complete Eviction Pack Generator
 *
 * Generates region-specific complete eviction packs including:
 * - All notices (Section 8/21, Notice to Leave)
 * - All court forms (N5, N5B, N119, Tribunal forms)
 * - Expert guidance documents
 * - Grounds support and evidence checklists
 * - Premium features (lifetime storage, priority support)
 *
 * Pricing: £149.99 one-time payment
 * Regions: England & Wales, Scotland
 */

import { generateDocument } from './generator';
import { generateSection8Notice, Section8NoticeData } from './section8-generator';
import { fillN5Form, fillN119Form, CaseData, fillN5BForm } from './official-forms-filler';
import type { ScotlandCaseData } from './scotland-forms-filler';
import { buildServiceContact } from '@/lib/documents/service-contact';
import {
  wizardFactsToEnglandWalesEviction,
  wizardFactsToScotlandEviction,
  buildScotlandEvictionCase,
} from './eviction-wizard-mapper';
import { generateWitnessStatement, extractWitnessStatementContext } from '@/lib/ai/witness-statement-generator';
import { generateComplianceAudit, extractComplianceAuditContext } from '@/lib/ai/compliance-audit-generator';
import { computeRiskAssessment } from '@/lib/case-intel/risk-assessment';
import fs from 'fs/promises';
import path from 'path';

// ============================================================================
// TYPES
// ============================================================================

export type Jurisdiction = 'england-wales' | 'scotland';

export interface EvictionCase {
  // Jurisdiction
  jurisdiction: Jurisdiction;

  // Case details
  case_id?: string;
  case_type: 'rent_arrears' | 'antisocial' | 'breach' | 'no_fault' | 'landlord_needs' | 'other';
  case_summary: string;

  // Landlord
  landlord_full_name: string;
  landlord_2_name?: string;
  landlord_address: string;
  landlord_address_line1?: string;
  landlord_address_town?: string;
  landlord_address_postcode?: string;
  landlord_email?: string;
  landlord_phone?: string;

  // Representation (England & Wales)
  solicitor_firm?: string;
  solicitor_address?: string;
  solicitor_phone?: string;
  solicitor_email?: string;
  dx_number?: string;

  // Explicit address-for-service override (if collected separately)
  service_address_line1?: string;
  service_address_line2?: string;
  service_address_town?: string;
  service_address_county?: string;
  service_postcode?: string;
  service_phone?: string;
  service_email?: string;

  // Tenant
  tenant_full_name: string;
  tenant_2_name?: string;
  property_address: string;
  property_address_line1?: string;
  property_address_town?: string;
  property_address_postcode?: string;

  // Tenancy
  tenancy_start_date: string;
  tenancy_type: 'fixed_term' | 'periodic' | 'assured_shorthold' | 'private_residential' | 'ast';
  fixed_term?: boolean;
  fixed_term_end_date?: string;
  rent_amount: number;
  rent_frequency: 'weekly' | 'fortnightly' | 'monthly' | 'quarterly' | 'yearly';
  payment_day: number;

  // Grounds for eviction
  grounds: GroundClaim[];

  // Arrears (if applicable)
  current_arrears?: number;
  arrears_at_notice_date?: number;
  arrears_breakdown?: Array<{
    period: string;
    amount_due: number;
    amount_paid: number;
    balance: number;
  }>;

  // Incident log (for antisocial/nuisance)
  incidents?: Array<{
    date: string;
    time?: string;
    description: string;
    witnesses?: string[];
    police_involved?: boolean;
    crime_number?: string;
  }>;

  // Breach details (if applicable)
  breach_type?: string;
  breach_description?: string;
  breach_start_date?: string;
  warnings_given?: Array<{
    date: string;
    method: string;
    description: string;
  }>;

  // Compliance
  deposit_protected?: boolean;
  deposit_amount?: number;
  deposit_scheme?: string;
  deposit_scheme_name?: 'DPS' | 'MyDeposits' | 'TDS' | 'SafeDeposits Scotland';
  deposit_protection_date?: string;
  deposit_reference?: string;
  gas_safety_certificate?: boolean;
  epc_rating?: string;
  eicr_certificate?: boolean;
  hmo_licensed?: boolean;
  landlord_registered?: boolean; // Scotland
  landlord_registration_number?: string; // Scotland

  // Court details
  court_name?: string;
  court_address?: string;

  // Additional data
  [key: string]: any;
}

export interface GroundClaim {
  code: string; // 'Ground 1', 'Ground 8', etc.
  title: string;
  particulars: string;
  evidence?: string;
  mandatory?: boolean;
}

export interface EvictionPackDocument {
  title: string;
  description: string;
  category: 'notice' | 'court_form' | 'guidance' | 'evidence_tool' | 'bonus';
  html?: string;
  pdf?: Buffer;
  file_name: string;
}

export interface CompleteEvictionPack {
  case_id: string;
  jurisdiction: Jurisdiction;
  pack_type: 'complete_eviction_pack';
  generated_at: string;
  documents: EvictionPackDocument[];
  metadata: {
    total_documents: number;
    includes_court_forms: boolean;
    includes_expert_guidance: boolean;
    includes_evidence_tools: boolean;
    premium_features: string[];
  };
}

// ============================================================================
// GROUND DEFINITIONS LOADER
// ============================================================================

/**
 * Load eviction grounds for jurisdiction
 */
export async function loadEvictionGrounds(jurisdiction: Jurisdiction): Promise<any> {
  const groundsPath = path.join(
    process.cwd(),
    'config',
    'jurisdictions',
    'uk',
    jurisdiction,
    'eviction_grounds.json'
  );

  try {
    const groundsData = await fs.readFile(groundsPath, 'utf-8');
    return JSON.parse(groundsData);
  } catch (error) {
    console.error(`Failed to load eviction grounds for ${jurisdiction}:`, error);
    throw new Error(`Eviction grounds not found for ${jurisdiction}`);
  }
}

/**
 * Get ground details by code
 */
export function getGroundDetails(grounds: any, groundCode: string): any {
  const groundKey = `ground_${groundCode.replace('Ground ', '').toLowerCase()}`;
  return grounds.grounds[groundKey];
}

// ============================================================================
// DOCUMENT GENERATORS
// ============================================================================

/**
 * Generate Step-by-Step Eviction Roadmap
 */
async function generateEvictionRoadmap(
  evictionCase: EvictionCase,
  groundsData: any
): Promise<EvictionPackDocument> {
  const jurisdiction = evictionCase.jurisdiction;

  let templatePath = '';
  if (jurisdiction === 'england-wales') {
    templatePath = 'uk/england-wales/templates/eviction/eviction_roadmap.hbs';
  } else if (jurisdiction === 'scotland') {
    templatePath = 'uk/scotland/templates/eviction_roadmap.hbs';
  } else {
    // Fallback to a shared roadmap template if we ever support NI / others
    templatePath = 'shared/templates/eviction_roadmap.hbs';
  }

  const data = {
    ...evictionCase,
    grounds_data: groundsData,
    current_date: new Date().toISOString().split('T')[0],
  };

  const doc = await generateDocument({
    templatePath,
    data,
    isPreview: false,
    outputFormat: 'both',
  });

  return {
    title: 'Step-by-Step Eviction Roadmap',
    description: 'Complete timeline and checklist for your eviction case',
    category: 'guidance',
    html: doc.html,
    pdf: doc.pdf,
    file_name: `eviction_roadmap_${jurisdiction}.pdf`,
  };
}

/**
 * Generate Evidence Collection Checklist
 */
async function generateEvidenceChecklist(
  evictionCase: EvictionCase,
  groundsData: any
): Promise<EvictionPackDocument> {
  const templatePath = 'shared/templates/evidence_collection_checklist.hbs';

  const data = {
    ...evictionCase,
    grounds_data: groundsData,
    required_evidence: evictionCase.grounds.map((g) => {
      const groundDetails = getGroundDetails(groundsData, g.code);
      return {
        ground: g.code,
        title: g.title,
        evidence_items: groundDetails?.required_evidence || [],
      };
    }),
  };

  const doc = await generateDocument({
    templatePath,
    data,
    isPreview: false,
    outputFormat: 'both',
  });

  return {
    title: 'Evidence Collection Checklist',
    description: 'Detailed checklist of all evidence you need to gather',
    category: 'evidence_tool',
    html: doc.html,
    pdf: doc.pdf,
    file_name: 'evidence_collection_checklist.pdf',
  };
}

/**
 * Generate Proof of Service Templates
 */
async function generateProofOfService(
  evictionCase: EvictionCase
): Promise<EvictionPackDocument> {
  const templatePath = 'shared/templates/proof_of_service.hbs';

  const data = {
    ...evictionCase,
    service_date: '',
    service_method: '',
    served_by: '',
  };

  const doc = await generateDocument({
    templatePath,
    data,
    isPreview: false,
    outputFormat: 'both',
  });

  return {
    title: 'Proof of Service Certificate',
    description: 'Template for proving you served the notice correctly',
    category: 'evidence_tool',
    html: doc.html,
    pdf: doc.pdf,
    file_name: 'proof_of_service_template.pdf',
  };
}

/**
 * Generate Expert Guidance Document
 */
async function generateExpertGuidance(
  evictionCase: EvictionCase,
  groundsData: any
): Promise<EvictionPackDocument> {
  const jurisdiction = evictionCase.jurisdiction;
  const templatePath = `uk/${jurisdiction}/templates/eviction/expert_guidance.hbs`;

  const data = {
    ...evictionCase,
    grounds_data: groundsData,
    common_mistakes: [],
    best_practices: [],
  };

  const doc = await generateDocument({
    templatePath,
    data,
    isPreview: false,
    outputFormat: 'both',
  });

  return {
    title: 'Expert Eviction Guidance',
    description:
      'Professional tips, common mistakes to avoid, and success strategies',
    category: 'guidance',
    html: doc.html,
    pdf: doc.pdf,
    file_name: 'expert_eviction_guidance.pdf',
  };
}

/**
 * Generate Timeline Expectations Document
 */
async function generateTimelineExpectations(
  evictionCase: EvictionCase,
  groundsData: any
): Promise<EvictionPackDocument> {
  const templatePath = 'shared/templates/eviction_timeline.hbs';

  const data = {
    ...evictionCase,
    grounds_data: groundsData,
    estimated_timeline: calculateEstimatedTimeline(evictionCase),
  };

  const doc = await generateDocument({
    templatePath,
    data,
    isPreview: false,
    outputFormat: 'both',
  });

  return {
    title: 'Eviction Timeline & Expectations',
    description: 'Realistic timeline for each stage of your eviction case',
    category: 'guidance',
    html: doc.html,
    pdf: doc.pdf,
    file_name: 'eviction_timeline_expectations.pdf',
  };
}

/**
 * Calculate leaving date based on notice period
 */
function calculateLeavingDate(noticePeriodDays: number): string {
  const today = new Date();
  const leavingDate = new Date(
    today.getTime() + noticePeriodDays * 24 * 60 * 60 * 1000
  );
  return leavingDate.toISOString().split('T')[0];
}


/**
 * Calculate estimated timeline based on jurisdiction and grounds
 */
function calculateEstimatedTimeline(evictionCase: EvictionCase): {
  notice_stage: { start: string; end: string };
  court_stage?: { start: string; end: string };
  enforcement_stage?: { start: string; end: string };
} {
  const baseDaysNotice = 14; // generic baseline – templates can explain nuances
  const baseDaysCourt = 90;
  const baseDaysEnforcement = 60;

  const today = new Date();

  const hasMandatoryGround = evictionCase.grounds?.some((g) => g.mandatory);
  const jurisdiction = evictionCase.jurisdiction;

  // Simple tweaks – you can refine per-ground in templates:
  let noticeDays = baseDaysNotice;
  let courtDays = baseDaysCourt;
  let enforcementDays = baseDaysEnforcement;

  if (jurisdiction === 'england-wales') {
    // Section 8 mandatory arrears / strong grounds often resolve a bit faster
    if (hasMandatoryGround) {
      courtDays -= 14;
    }
  } else if (jurisdiction === 'scotland') {
    // Tribunal tends to be slower in practice
    courtDays += 30;
  }

  const noticeStart = today;
  const noticeEnd = new Date(
    noticeStart.getTime() + noticeDays * 24 * 60 * 60 * 1000
  );

  const courtStart = new Date(noticeEnd.getTime());
  const courtEnd = new Date(
    courtStart.getTime() + courtDays * 24 * 60 * 60 * 1000
  );

  const enforcementStart = new Date(courtEnd.getTime());
  const enforcementEnd = new Date(
    enforcementStart.getTime() + enforcementDays * 24 * 60 * 60 * 1000
  );

  const fmt = (d: Date) => d.toISOString().split('T')[0];

  return {
    notice_stage: {
      start: fmt(noticeStart),
      end: fmt(noticeEnd),
    },
    court_stage: {
      start: fmt(courtStart),
      end: fmt(courtEnd),
    },
    enforcement_stage: {
      start: fmt(enforcementStart),
      end: fmt(enforcementEnd),
    },
  };
}

// ============================================================================
// REGION-SPECIFIC GENERATORS
// ============================================================================

/**
 * Generate England & Wales Eviction Pack
 */
async function generateEnglandWalesEvictionPack(
  evictionCase: EvictionCase,
  caseData: CaseData,
  groundsData: any
): Promise<EvictionPackDocument[]> {
  const documents: EvictionPackDocument[] = [];

    // 1. Section 8 Notice (if fault-based grounds)
  if (evictionCase.grounds.length > 0) {
    const noticePeriodDays = 14; // baseline; templates can explain nuances
    const earliestPossessionDate = calculateLeavingDate(noticePeriodDays);

    const section8Data: Section8NoticeData = {
      landlord_full_name: evictionCase.landlord_full_name,
      landlord_address: evictionCase.landlord_address,
      tenant_full_name: evictionCase.tenant_full_name,
      property_address: evictionCase.property_address,
      tenancy_start_date: evictionCase.tenancy_start_date,
      rent_amount: evictionCase.rent_amount,
      rent_frequency: evictionCase.rent_frequency,
      payment_date: evictionCase.payment_day,
      grounds: evictionCase.grounds.map((g) => ({
        code: parseInt(g.code.replace('Ground ', '')),
        title: g.title,
        legal_basis: getGroundDetails(groundsData, g.code)?.statute || '',
        particulars: g.particulars,
        supporting_evidence: g.evidence,
        mandatory: g.mandatory || false,
      })),
      notice_period_days: noticePeriodDays,
      earliest_possession_date: earliestPossessionDate,
      any_mandatory_ground: evictionCase.grounds.some((g) => g.mandatory),
      any_discretionary_ground: evictionCase.grounds.some((g) => !g.mandatory),
    };

    const section8Doc = await generateSection8Notice(section8Data, false);

    documents.push({
      title: 'Section 8 Notice - Notice Seeking Possession',
      description: 'Official notice to tenant citing grounds for possession',
      category: 'notice',
      html: section8Doc.html,
      pdf: section8Doc.pdf,
      file_name: 'section8_notice.pdf',
    });
  }

  // 2. Section 21 Notice (if no-fault)
  if (evictionCase.case_type === 'no_fault') {
    const section21Doc = await generateDocument({
      templatePath: 'uk/england-wales/templates/eviction/section21_form6a.hbs',
      data: evictionCase,
      isPreview: false,
      outputFormat: 'both',
    });

    documents.push({
      title: 'Section 21 Notice - Form 6A',
      description: 'Official no-fault eviction notice (2 months)',
      category: 'notice',
      html: section21Doc.html,
      pdf: section21Doc.pdf,
      file_name: 'section21_form6a.pdf',
    });

    // Accelerated possession claim (N5B)
    const n5bPdf = await fillN5BForm({
      ...caseData,
      landlord_full_name: caseData.landlord_full_name || evictionCase.landlord_full_name,
      landlord_address: caseData.landlord_address || evictionCase.landlord_address,
      landlord_postcode: caseData.landlord_postcode || evictionCase.landlord_address_postcode,
      tenant_full_name: caseData.tenant_full_name || evictionCase.tenant_full_name,
      property_address: caseData.property_address || evictionCase.property_address,
      property_postcode: caseData.property_postcode || evictionCase.property_address_postcode,
      tenancy_start_date: caseData.tenancy_start_date || evictionCase.tenancy_start_date,
      rent_amount: caseData.rent_amount ?? evictionCase.rent_amount,
      rent_frequency: caseData.rent_frequency || evictionCase.rent_frequency,
      deposit_protection_date: caseData.deposit_protection_date,
      deposit_reference: caseData.deposit_reference,
      deposit_scheme: caseData.deposit_scheme,
      section_21_notice_date:
        caseData.section_21_notice_date || caseData.notice_served_date || new Date().toISOString().split('T')[0],
      notice_expiry_date: caseData.notice_expiry_date,
      signature_date: caseData.signature_date || new Date().toISOString().split('T')[0],
      signatory_name: caseData.signatory_name || evictionCase.landlord_full_name,
      court_name: caseData.court_name || 'County Court',
    });

    documents.push({
      title: 'N5B Accelerated Possession Claim',
      description: 'Accelerated possession claim for Section 21 cases',
      category: 'court_form',
      pdf: Buffer.from(n5bPdf),
      file_name: 'n5b_accelerated_possession.pdf',
    });
  }

  // 3. N5 Claim Form
  const service = buildServiceContact({ ...evictionCase, ...caseData });

  const enrichedCaseData: CaseData = {
    ...caseData,
    landlord_full_name: caseData.landlord_full_name || evictionCase.landlord_full_name,
    landlord_address: caseData.landlord_address || evictionCase.landlord_address,
    landlord_postcode: caseData.landlord_postcode || evictionCase.landlord_address_postcode,
    landlord_phone: caseData.landlord_phone || evictionCase.landlord_phone,
    landlord_email: caseData.landlord_email || evictionCase.landlord_email,
    tenant_full_name: caseData.tenant_full_name || evictionCase.tenant_full_name,
    property_address: caseData.property_address || evictionCase.property_address,
    property_postcode: caseData.property_postcode || evictionCase.property_address_postcode,
    tenancy_start_date: caseData.tenancy_start_date || evictionCase.tenancy_start_date,
    rent_amount: caseData.rent_amount ?? evictionCase.rent_amount,
    rent_frequency: caseData.rent_frequency || evictionCase.rent_frequency,
    signatory_name: caseData.signatory_name || evictionCase.landlord_full_name,
    signature_date: caseData.signature_date || new Date().toISOString().split('T')[0],
    court_name: caseData.court_name || evictionCase.court_name || 'County Court',
    notice_served_date:
      caseData.notice_served_date ||
      caseData.section_8_notice_date ||
      caseData.section_21_notice_date ||
      evictionCase['notice_date'],
    service_address_line1: service.service_address_line1,
    service_address_line2: service.service_address_line2,
    service_address_town: service.service_address_town,
    service_address_county: service.service_address_county,
    service_postcode: service.service_postcode,
    service_phone: service.service_phone,
    service_email: service.service_email,
  };

  const n5Pdf = await fillN5Form(enrichedCaseData);
  documents.push({
    title: 'Form N5 - Claim for Possession',
    description: 'Official court claim form for possession proceedings',
    category: 'court_form',
    pdf: Buffer.from(n5Pdf),
    file_name: 'n5_claim_for_possession.pdf',
  });

  // 4. N119 Particulars of Claim
  const n119Pdf = await fillN119Form(enrichedCaseData);
  documents.push({
    title: 'Form N119 - Particulars of Claim',
    description: 'Detailed particulars supporting your possession claim',
    category: 'court_form',
    pdf: Buffer.from(n119Pdf),
    file_name: 'n119_particulars_of_claim.pdf',
  });

  return documents;
}

/**
 * Generate Scotland Eviction Pack
 */
async function generateScotlandEvictionPack(
  evictionCase: EvictionCase,
  scotlandData: ScotlandCaseData
): Promise<EvictionPackDocument[]> {
  const documents: EvictionPackDocument[] = [];

  const { fillScotlandOfficialForm } = await import('./scotland-forms-filler');

  // 1. Notice to Leave (generated via Handlebars template because official PDF is not fillable)
  const noticeToLeaveDoc = await generateDocument({
    templatePath: 'uk/scotland/templates/eviction/notice_to_leave.hbs',
    data: scotlandData,
    outputFormat: 'both',
  });

  if (!noticeToLeaveDoc.pdf) {
    throw new Error('Failed to generate Notice to Leave PDF for Scotland');
  }

  documents.push({
    title: 'Notice to Leave',
    description: 'Official notice under Private Housing (Tenancies) (Scotland) Act 2016',
    category: 'notice',
    html: noticeToLeaveDoc.html,
    pdf: noticeToLeaveDoc.pdf,
    file_name: 'notice_to_leave.pdf',
  });

  // 2. Tribunal Application Form E (Official Form)
  const formEPdf = await fillScotlandOfficialForm('form_e', scotlandData);

  documents.push({
    title: 'Form E - Tribunal Application for Eviction Order',
    description: 'Application to First-tier Tribunal for Scotland (Housing and Property Chamber)',
    category: 'court_form',
    pdf: Buffer.from(formEPdf),
    file_name: 'tribunal_form_e_application.pdf',
  });

  return documents;
}

// ============================================================================
// MAIN GENERATOR
// ============================================================================

/**
 * Generate Complete Eviction Pack
 *
 * Includes everything a landlord needs from notice to possession order:
 * - All region-specific notices
 * - All court/tribunal forms
 * - Expert guidance
 * - Evidence collection tools
 * - Timeline expectations
 * - Proof of service templates
 *
 * Price: £149.99 one-time
 */
export async function generateCompleteEvictionPack(
  wizardFacts: any
): Promise<CompleteEvictionPack> {
  const caseId = wizardFacts?.__meta?.case_id || wizardFacts?.case_id || `EVICT-${Date.now()}`;
  const jurisdiction =
    wizardFacts?.__meta?.jurisdiction || wizardFacts?.jurisdiction || ('england-wales' as Jurisdiction);

  console.log(`\n📦 Generating Complete Eviction Pack for ${jurisdiction}...`);
  console.log('='.repeat(80));

  // Load jurisdiction-specific grounds
  const groundsData = await loadEvictionGrounds(jurisdiction);

  // Initialize documents array
  const documents: EvictionPackDocument[] = [];

  // 1. Generate region-specific notices and court forms
  let regionDocs: EvictionPackDocument[] = [];

  let evictionCase: EvictionCase;

  if (jurisdiction === 'england-wales') {
    const { evictionCase: ewCase, caseData } = wizardFactsToEnglandWalesEviction(caseId, wizardFacts);
    evictionCase = ewCase;
    regionDocs = await generateEnglandWalesEvictionPack(evictionCase, caseData, groundsData);
  } else {
    const { scotlandCaseData } = wizardFactsToScotlandEviction(caseId, wizardFacts);
    evictionCase = buildScotlandEvictionCase(caseId, scotlandCaseData);
    regionDocs = await generateScotlandEvictionPack(evictionCase, scotlandCaseData);
  }

  documents.push(...regionDocs);

  // 2. Generate expert guidance documents
  const roadmap = await generateEvictionRoadmap(evictionCase, groundsData);
  documents.push(roadmap);

  const guidance = await generateExpertGuidance(evictionCase, groundsData);
  documents.push(guidance);

  const timeline = await generateTimelineExpectations(evictionCase, groundsData);
  documents.push(timeline);

  // 3. Generate evidence tools
  const evidenceChecklist = await generateEvidenceChecklist(evictionCase, groundsData);
  documents.push(evidenceChecklist);

  const proofOfService = await generateProofOfService(evictionCase);
  documents.push(proofOfService);

  // 3.1 Generate witness statement (AI-powered premium feature)
  try {
    const witnessStatementContext = extractWitnessStatementContext(wizardFacts);
    const witnessStatementContent = await generateWitnessStatement(wizardFacts, witnessStatementContext);

    const witnessStatementDoc = await generateDocument({
      templatePath: `uk/${jurisdiction}/templates/eviction/witness-statement.hbs`,
      data: {
        ...evictionCase,
        witness_statement: witnessStatementContent,
        landlord_address: evictionCase.landlord_address,
        court_name: jurisdiction === 'scotland' ? 'First-tier Tribunal' : 'County Court',
      },
      isPreview: false,
      outputFormat: 'both',
    });

    documents.push({
      title: 'Witness Statement',
      description: 'AI-drafted witness statement for court proceedings',
      category: 'supporting_documents',
      html: witnessStatementDoc.html,
      pdf: witnessStatementDoc.pdf,
      file_name: 'witness_statement.pdf',
    });

    console.log('✅ Generated witness statement');
  } catch (error) {
    console.error('⚠️  Failed to generate witness statement:', error);
    // Don't fail the entire pack if witness statement generation fails
  }

  // 3.2 Generate compliance audit (AI-powered premium feature)
  try {
    const complianceAuditContext = extractComplianceAuditContext(wizardFacts);
    const complianceAuditContent = await generateComplianceAudit(wizardFacts, complianceAuditContext);

    const complianceAuditDoc = await generateDocument({
      templatePath: `uk/${jurisdiction}/templates/eviction/compliance-audit.hbs`,
      data: {
        ...evictionCase,
        compliance_audit: complianceAuditContent,
        current_date: new Date().toISOString().split('T')[0],
        notice_type: evictionCase.grounds[0]?.ground_id || 'Not specified',
      },
      isPreview: false,
      outputFormat: 'both',
    });

    documents.push({
      title: 'Compliance Audit Report',
      description: 'AI-powered compliance check for eviction proceedings',
      category: 'guidance',
      html: complianceAuditDoc.html,
      pdf: complianceAuditDoc.pdf,
      file_name: 'compliance_audit.pdf',
    });

    console.log('✅ Generated compliance audit');
  } catch (error) {
    console.error('⚠️  Failed to generate compliance audit:', error);
    // Don't fail the entire pack if compliance audit generation fails
  }

  // 3.3 Generate risk report (premium feature)
  try {
    const riskAssessment = computeRiskAssessment(wizardFacts);

    const riskReportDoc = await generateDocument({
      templatePath: `uk/${jurisdiction}/templates/eviction/risk-report.hbs`,
      data: {
        ...evictionCase,
        risk_assessment: riskAssessment,
        current_date: new Date().toISOString().split('T')[0],
        case_type: evictionCase.case_type.replace('_', ' ').toUpperCase(),
      },
      isPreview: false,
      outputFormat: 'both',
    });

    documents.push({
      title: 'Case Risk Assessment Report',
      description: 'Comprehensive risk analysis and success probability assessment',
      category: 'guidance',
      html: riskReportDoc.html,
      pdf: riskReportDoc.pdf,
      file_name: 'risk_assessment.pdf',
    });

    console.log('✅ Generated risk assessment report');
  } catch (error) {
    console.error('⚠️  Failed to generate risk report:', error);
    // Don't fail the entire pack if risk report generation fails
  }

  // 4. Generate case summary document
  const caseSummaryDoc = await generateDocument({
    templatePath: 'shared/templates/eviction_case_summary.hbs',
    data: {
      ...evictionCase,
      grounds_data: groundsData,
      generated_at: new Date().toISOString(),
    },
    isPreview: false,
    outputFormat: 'both',
  });

  documents.push({
    title: 'Eviction Case Summary',
    description: 'Complete summary of your eviction case and selected grounds',
    category: 'guidance',
    html: caseSummaryDoc.html,
    pdf: caseSummaryDoc.pdf,
    file_name: 'eviction_case_summary.pdf',
  });

  console.log(`✅ Generated ${documents.length} documents for complete eviction pack`);

  return {
    case_id: evictionCase.case_id || `EVICT-${Date.now()}`,
    jurisdiction: evictionCase.jurisdiction,
    pack_type: 'complete_eviction_pack',
    generated_at: new Date().toISOString(),
    documents,
    metadata: {
      total_documents: documents.length,
      includes_court_forms: documents.some((d) => d.category === 'court_form'),
      includes_expert_guidance: documents.some((d) => d.category === 'guidance'),
      includes_evidence_tools: documents.some((d) => d.category === 'evidence_tool'),
      premium_features: [
        'Lifetime Cloud Storage',
        'Priority Support',
        'Unlimited Regenerations',
        'Guided Case Analysis',
        'All Grounds Support',
        'Evidence Collection Tools',
        'Step-by-Step Roadmap',
        'Timeline Expectations',
        'Expert Guidance',
        'Proof of Service Templates',
      ],
    },
  };
}

/**
 * Generate Notice Only Pack (£29.99)
 *
 * Includes only the eviction notice (Section 8/21, Notice to Leave, or Notice to Quit)
 */
export async function generateNoticeOnlyPack(
  wizardFacts: any
): Promise<CompleteEvictionPack> {
  const caseId = wizardFacts?.__meta?.case_id || wizardFacts?.case_id || `EVICT-NOTICE-${Date.now()}`;
  const jurisdiction =
    wizardFacts?.__meta?.jurisdiction || wizardFacts?.jurisdiction || ('england-wales' as Jurisdiction);

  console.log(`\n📄 Generating Notice Only Pack for ${jurisdiction}...`);

  const groundsData = await loadEvictionGrounds(jurisdiction);
  const documents: EvictionPackDocument[] = [];

  if (jurisdiction === 'england-wales') {
    const { evictionCase } = wizardFactsToEnglandWalesEviction(caseId, wizardFacts);
    // Section 8 or Section 21
    if (evictionCase.case_type === 'no_fault') {
      const section21Doc = await generateDocument({
        templatePath: 'uk/england-wales/templates/eviction/section21_form6a.hbs',
        data: evictionCase,
        isPreview: false,
        outputFormat: 'both',
      });
      documents.push({
        title: 'Section 21 Notice - Form 6A',
        description: 'No-fault eviction notice',
        category: 'notice',
        html: section21Doc.html,
        pdf: section21Doc.pdf,
        file_name: 'section21_form6a.pdf',
      });
    } else {
      const section8Doc = await generateSection8Notice(
        {
          landlord_full_name: evictionCase.landlord_full_name,
          landlord_address: evictionCase.landlord_address,
          tenant_full_name: evictionCase.tenant_full_name,
          property_address: evictionCase.property_address,
          tenancy_start_date: evictionCase.tenancy_start_date,
          rent_amount: evictionCase.rent_amount,
          rent_frequency: evictionCase.rent_frequency,
          payment_date: evictionCase.payment_day,
          grounds: evictionCase.grounds.map((g) => ({
            code: parseInt(g.code.replace('Ground ', '')),
            title: g.title,
            legal_basis: getGroundDetails(groundsData, g.code)?.statute || '',
            particulars: g.particulars,
            supporting_evidence: g.evidence,
            mandatory: g.mandatory || false,
          })),
          notice_period_days: 14,
          earliest_possession_date: '',
          any_mandatory_ground: evictionCase.grounds.some((g) => g.mandatory),
          any_discretionary_ground: evictionCase.grounds.some((g) => !g.mandatory),
        },
        false
      );
      documents.push({
        title: 'Section 8 Notice',
        description: 'Notice seeking possession',
        category: 'notice',
        html: section8Doc.html,
        pdf: section8Doc.pdf,
        file_name: 'section8_notice.pdf',
      });
    }
  } else if (jurisdiction === 'scotland') {
    const { scotlandCaseData } = wizardFactsToScotlandEviction(caseId, wizardFacts);
    const evictionCase = buildScotlandEvictionCase(caseId, scotlandCaseData);
    const noticeDoc = await generateDocument({
      templatePath: 'uk/scotland/templates/notice_to_leave.hbs',
      data: { ...evictionCase, ...scotlandCaseData },
      isPreview: false,
      outputFormat: 'both',
    });
    documents.push({
      title: 'Notice to Leave',
      description: 'Statutory eviction notice',
      category: 'notice',
      html: noticeDoc.html,
      pdf: noticeDoc.pdf,
      file_name: 'notice_to_leave.pdf',
    });
  }

  return {
    case_id: caseId,
    jurisdiction,
    pack_type: 'complete_eviction_pack',
    generated_at: new Date().toISOString(),
    documents,
    metadata: {
      total_documents: documents.length,
      includes_court_forms: false,
      includes_expert_guidance: false,
      includes_evidence_tools: false,
      premium_features: ['Single Notice Generation'],
    },
  };
}
